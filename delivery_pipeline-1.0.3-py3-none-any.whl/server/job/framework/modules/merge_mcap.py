"""
通用 MCAP 合并模块

功能：将多个 MCAP 文件按全局时间戳顺序合并为一个 MCAP 文件。
约束：所有输入文件的 topic 必须互不相交，发现冲突直接报错。
"""

import os
from pathlib import Path
from typing import List, Dict, Tuple, Optional, NamedTuple

from mcap.reader import NonSeekingReader
from mcap.writer import Writer

from server.utils.log_utils import *


class _McapMessage(NamedTuple):
    timestamp: int
    schema: object
    channel: object
    message: object


def _read_messages(mcap_path: str) -> Tuple[List[_McapMessage], set]:
    messages: List[_McapMessage] = []
    topics: set = set()
    with open(mcap_path, "rb") as f:
        reader = NonSeekingReader(f)
        for schema, channel, message in reader.iter_messages():
            ts = message.publish_time or message.log_time
            if ts is None:
                logger.warn(f"消息无时间戳，跳过 | Topic: {channel.topic}")
                continue
            topics.add(channel.topic)
            messages.append(_McapMessage(
                timestamp=ts,
                schema=schema,
                channel=channel,
                message=message,
            ))
    return messages, topics


def merge_mcap_files(input_paths: List[str], output_path: str) -> Tuple[bool, str, Optional[Dict]]:
    """
    将多个 mcap 文件按全局时间戳顺序合并为一个 mcap 文件。

    Args:
        input_paths: 输入 mcap 文件路径列表
        output_path: 输出 mcap 文件路径

    Returns:
        (is_success, err_msg, ret_data)
        ret_data: {"total_messages": int, "file_count": int, "duration": float, "record_time_ms": int}
    """
    logger.info("=" * 80)
    logger.info("开始合并 MCAP 文件（按时间戳全局排序）")
    logger.info("=" * 80)
    logger.info(f"输入文件数: {len(input_paths)}")
    logger.info(f"输出文件: {Path(output_path).name}")

    if not input_paths:
        return False, "输入 mcap 文件列表为空", None

    # 步骤1：逐个读取文件，并检查 topic 是否与已读文件冲突
    all_messages: List[_McapMessage] = []
    topic_owner: Dict[str, str] = {}
    for path in input_paths:
        logger.info(f"\n读取文件: {Path(path).name}")
        messages, topics = _read_messages(path)
        conflicts = sorted(t for t in topics if t in topic_owner and topic_owner[t] != path)
        if conflicts:
            owner = topic_owner[conflicts[0]]
            err = f"topic 冲突: {conflicts} 同时存在于 {Path(owner).name} 和 {Path(path).name}"
            logger.error(err)
            return False, err, None
        for t in topics:
            topic_owner[t] = path
        logger.info(f"  消息数: {len(messages)}, topic 数: {len(topics)}")
        all_messages.extend(messages)

    # 步骤2：按时间戳排序
    all_messages.sort(key=lambda m: m.timestamp)
    if all_messages:
        logger.info(f"\n合并后总消息数: {len(all_messages)}")
        logger.info(f"时间范围: {all_messages[0].timestamp / 1e9:.2f}s ~ {all_messages[-1].timestamp / 1e9:.2f}s")

    # 步骤3：写入合并后的文件
    out_dir = os.path.dirname(output_path)
    if out_dir:
        os.makedirs(out_dir, exist_ok=True)

    schema_map: Dict[tuple, int] = {}
    channel_map: Dict[tuple, int] = {}
    written = 0
    with open(output_path, "wb") as out_f:
        writer = Writer(out_f)
        writer.start()

        for m in all_messages:
            schema = m.schema
            channel = m.channel
            message = m.message

            schema_key = (schema.name, schema.encoding, schema.data)
            if schema_key not in schema_map:
                schema_map[schema_key] = writer.register_schema(
                    name=schema.name,
                    encoding=schema.encoding,
                    data=schema.data,
                )

            channel_key = (channel.topic, channel.message_encoding, schema_key)
            if channel_key not in channel_map:
                channel_map[channel_key] = writer.register_channel(
                    schema_id=schema_map[schema_key],
                    topic=channel.topic,
                    message_encoding=channel.message_encoding,
                    metadata=channel.metadata,
                )

            writer.add_message(
                channel_id=channel_map[channel_key],
                log_time=message.log_time,
                data=message.data,
                publish_time=message.publish_time,
            )
            written += 1
            if written % 1000 == 0:
                logger.info(f"  已写入 {written}/{len(all_messages)} 条消息...")

        writer.finish()

    duration = 0.0
    record_time_ms = 0
    if all_messages:
        duration = (all_messages[-1].timestamp - all_messages[0].timestamp) / 1e9
        record_time_ms = int(all_messages[0].timestamp // 1e6)

    logger.info("\n" + "=" * 80)
    logger.info("合并完成！")
    logger.info("=" * 80)
    logger.info(f"输出文件路径: {output_path}")
    logger.info(f"成功写入消息数: {written}")
    logger.info(f"时长: {duration:.2f}s")

    return True, "", {
        "total_messages": written,
        "file_count": len(input_paths),
        "duration": duration,
        "record_time_ms": record_time_ms,
    }
