"""Trim a successful group's output directory.

Only `result.json` plus the final mcap (`delivery.mcap`,
`merged_output_pose6d.mcap`, or `merged_output_ego_vio.mcap` depending on
which variant ran) stay at the group root. Everything else moves into a
sibling `debug/` for post-mortem. `metadata.json` lives only inside
`debug/work/convert/` — it's available for inspection but not part of
the user-facing root.

Runs only on the success path; failed groups keep all intermediates in
place so the user can investigate.
"""
import os
import shutil
import sys

_KEEP_AT_ROOT = {
    "result.json",
    "delivery.mcap",
    "merged_output_ego_vio.mcap",
    "merged_output_pose6d.mcap",
}
_DEBUG_DIR = "debug"


def _replace(dst: str) -> None:
    if not os.path.exists(dst):
        return
    if os.path.isdir(dst) and not os.path.islink(dst):
        shutil.rmtree(dst, ignore_errors=True)
    else:
        try:
            os.remove(dst)
        except OSError:
            pass


def trim_output_dir(output_dir: str) -> None:
    if not os.path.isdir(output_dir):
        return
    debug_dir = os.path.join(output_dir, _DEBUG_DIR)
    keep = _KEEP_AT_ROOT | {_DEBUG_DIR}
    for name in os.listdir(output_dir):
        if name in keep:
            continue
        src = os.path.join(output_dir, name)
        os.makedirs(debug_dir, exist_ok=True)
        dst = os.path.join(debug_dir, name)
        _replace(dst)
        try:
            shutil.move(src, dst)
        except OSError as e:
            print(f"[cleanup] could not move {src} -> {dst}: {e}", file=sys.stderr)
