"""Load and validate the local YAML config.

Field names mirror the `db_info` + `event_groups` columns the underlying
jobs read, so their `run_main`s consume the YAML directly. Anything we can
read from the file itself (cpu_seq from the filename, duration from the mcap
summary, group_uuid from the trailing 8-hex token) is auto-derived when the
YAML omits it; only `inputs[*].file_path` and `output_dir` are strictly
required from the user.
"""
import argparse
import os
import re
import sys

import yaml

REQUIRED_TOP = ("inputs", "output_dir")
REQUIRED_INPUT = ("file_path",)
ALLOWED_STEPS = ("qc", "merge", "vio", "vio_check", "pose6d", "pose6d_check", "convert")

_BIZ_ROLE_ALIASES = (
    ("sub_left", "sub_left"),
    ("sub_right", "sub_right"),
    ("center_leader", "master"),
    ("leader", "master"),
    ("master", "master"),
)

_DEVICE_TO_TOKEN = {
    ("ego", "master"): "ego-master",
    ("finger", "sub_left"): "finger-left",
    ("finger", "sub_right"): "finger-right",
}

_CPU_SEQ_RE = re.compile(r"\b([0-9a-f]{16})\b")
_GROUP_UUID_RE = re.compile(r"_([0-9a-f]{8})\.mcap$")
_PLATFORM_HYPHEN_RE = re.compile(r"^(DAS-(?:EGO|F))-", re.IGNORECASE)
_PLATFORM_EGO_UNDERSCORE_RE = re.compile(r"^DAS-(?:Ego|EGO)_", re.IGNORECASE)
_PLATFORM_FINGER_RE = re.compile(r"(?:^das[_-]finger|_finger_)", re.IGNORECASE)


class ConfigError(Exception):
    pass


def load_config(path: str) -> dict:
    if not os.path.isfile(path):
        raise ConfigError(f"config file not found: {path}")
    with open(path, "r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f)
    if not isinstance(cfg, dict):
        raise ConfigError(f"config root must be a mapping, got {type(cfg).__name__}")
    return normalize(cfg)


def normalize(cfg: dict) -> dict:
    """Run the same autofill steps `load_config` does, on an already-parsed dict."""
    _validate_required(cfg)
    _autofill_inputs(cfg)
    _autofill_top_level(cfg)
    _autofill_metadata(cfg)
    _validate_consistency(cfg)
    cfg.setdefault("steps", list(ALLOWED_STEPS))
    return cfg


def _validate_required(cfg: dict) -> None:
    missing = [k for k in REQUIRED_TOP if k not in cfg]
    if missing:
        raise ConfigError(f"missing top-level keys: {missing}")

    inputs = cfg["inputs"]
    if not isinstance(inputs, list) or not inputs:
        raise ConfigError("inputs must be a non-empty list")

    for idx, item in enumerate(inputs):
        if not isinstance(item, dict):
            raise ConfigError(f"inputs[{idx}] must be a mapping")
        miss = [k for k in REQUIRED_INPUT if k not in item]
        if miss:
            raise ConfigError(f"inputs[{idx}] missing keys: {miss}")
        if not os.path.isfile(item["file_path"]):
            raise ConfigError(
                f"inputs[{idx}].file_path does not exist: {item['file_path']}"
            )

    steps = cfg.get("steps")
    if steps is not None:
        if not isinstance(steps, list) or not steps:
            raise ConfigError("steps must be a non-empty list when provided")
        bad = [s for s in steps if s not in ALLOWED_STEPS]
        if bad:
            raise ConfigError(f"steps contains unsupported entries: {bad}")
        cfg["steps"] = steps


def _parse_filename(filename: str) -> dict:
    out: dict = {}
    m = _PLATFORM_HYPHEN_RE.match(filename)
    if m:
        out["platform"] = m.group(1).upper()
    elif _PLATFORM_EGO_UNDERSCORE_RE.match(filename):
        out["platform"] = "DAS-EGO"
    elif _PLATFORM_FINGER_RE.search(filename):
        out["platform"] = "DAS-F"

    m = _CPU_SEQ_RE.search(filename)
    if m:
        out["cpu_seq"] = m.group(1)

    m = _GROUP_UUID_RE.search(filename)
    if m:
        out["group_uuid"] = m.group(1)

    stem_lower = filename.lower()
    for token, canonical in _BIZ_ROLE_ALIASES:
        if (f"_{token}_" in stem_lower
                or stem_lower.endswith(f"_{token}.mcap")):
            out["biz_role"] = canonical
            break

    return out


def _autofill_inputs(cfg: dict) -> None:
    inputs = cfg["inputs"]
    seen_roles = set()
    for idx, item in enumerate(inputs):
        derived = _parse_filename(os.path.basename(item["file_path"]))

        for key in ("platform", "biz_role"):
            if key not in item or item[key] in (None, ""):
                if key in derived:
                    item[key] = derived[key]
                else:
                    raise ConfigError(
                        f"inputs[{idx}] missing '{key}' and could not be "
                        f"derived from filename: {item['file_path']}"
                    )

        if "cpu_seq" not in item or item["cpu_seq"] in (None, ""):
            item["cpu_seq"] = derived.get("cpu_seq", "")

        if "token" not in item or item["token"] in (None, ""):
            device_kind = "ego" if item["platform"].endswith("EGO") else "finger"
            token_key = (device_kind, item["biz_role"])
            if token_key in _DEVICE_TO_TOKEN:
                item["token"] = _DEVICE_TO_TOKEN[token_key]
            else:
                raise ConfigError(
                    f"inputs[{idx}] cannot derive token for "
                    f"platform={item['platform']} biz_role={item['biz_role']}"
                )

        role = (item["platform"], item["biz_role"])
        if role in seen_roles:
            raise ConfigError(f"inputs[{idx}] duplicate platform/biz_role: {role}")
        seen_roles.add(role)


def _autofill_top_level(cfg: dict) -> None:
    inputs = cfg["inputs"]

    if "group_uuid" not in cfg or cfg["group_uuid"] in (None, ""):
        cfg["group_uuid"] = _resolve_group_uuid(inputs)

    cfg.setdefault("group_info", {})
    if not isinstance(cfg["group_info"], dict):
        raise ConfigError("group_info must be a mapping")
    gi = cfg["group_info"]

    if "collect_device_schema" not in gi or gi["collect_device_schema"] in (None, ""):
        parts = []
        for item in inputs:
            device_kind = "ego" if item["platform"].endswith("EGO") else "finger"
            parts.append(f"{device_kind}:{item['biz_role']}")
        gi["collect_device_schema"] = "+".join(parts)


def _resolve_group_uuid(inputs: list) -> str:
    finger_uuids: set = set()
    for item in inputs:
        if item["platform"] == "DAS-F":
            m = _GROUP_UUID_RE.search(os.path.basename(item["file_path"]))
            if m:
                finger_uuids.add(m.group(1))

    ego_uuids: set = set()
    for item in inputs:
        if item["platform"] != "DAS-EGO":
            continue
        stem = os.path.basename(item["file_path"]).lower()
        m = _GROUP_UUID_RE.search(stem)
        if m:
            ego_uuids.add(m.group(1))
            continue
        hits = [
            u for u in finger_uuids
            if re.search(rf"(?:^|_){u}(?:$|_|\.)", stem)
        ]
        if len(hits) != 1:
            raise ConfigError(
                f"ego filename {stem!r} matches {len(hits)} candidate "
                f"group_uuids from fingers ({sorted(finger_uuids)}); "
                f"need exactly one"
            )
        ego_uuids.add(hits[0])

    candidates = finger_uuids | ego_uuids
    if len(candidates) == 1:
        return next(iter(candidates))
    if len(candidates) > 1:
        raise ConfigError(
            f"inputs do not share a group_uuid; got {sorted(candidates)}"
        )
    raise ConfigError(
        "group_uuid not provided and could not be derived from any input filename"
    )


def _autofill_metadata(cfg: dict) -> None:
    inputs = cfg["inputs"]
    default_count = len(inputs)
    cfg["group_info"].setdefault("group_count", default_count)

    for idx, item in enumerate(inputs):
        item.setdefault("group_count", default_count)
        need_duration = "duration" not in item or item["duration"] in (None, "")
        need_record = "record_time_ms" not in item or item["record_time_ms"] in (None, "")
        if not (need_duration or need_record):
            continue
        try:
            duration_s, record_time_ms = _read_mcap_metadata(item["file_path"])
        except Exception as e:
            raise ConfigError(
                f"inputs[{idx}] missing duration/record_time_ms and could not be "
                f"derived from mcap {item['file_path']}: {e}"
            ) from e
        if need_duration:
            item["duration"] = duration_s
        if need_record:
            item["record_time_ms"] = record_time_ms

    if "duration" not in cfg["group_info"] or cfg["group_info"]["duration"] in (None, ""):
        cfg["group_info"]["duration"] = max(item["duration"] for item in inputs)

    if "cpu_seqs" not in cfg["group_info"] or cfg["group_info"]["cpu_seqs"] in (None, ""):
        cfg["group_info"]["cpu_seqs"] = [item["cpu_seq"][:6] for item in inputs]


def _read_mcap_metadata(path: str):
    from mcap.reader import make_reader

    with open(path, "rb") as f:
        reader = make_reader(f)
        summary = reader.get_summary()
    stats = getattr(summary, "statistics", None) if summary else None
    if not stats:
        raise ConfigError(f"mcap has no summary statistics: {path}")
    start_ns = stats.message_start_time
    end_ns = stats.message_end_time
    if not start_ns or not end_ns or end_ns < start_ns:
        raise ConfigError(f"mcap statistics have invalid timestamps: {path}")
    return (end_ns - start_ns) / 1e9, start_ns // 1_000_000


def _validate_consistency(cfg: dict) -> None:
    inputs = cfg["inputs"]
    expected = cfg["group_info"].get("group_count")
    if expected and len(inputs) != expected:
        raise ConfigError(
            f"group_info.group_count={expected} != len(inputs)={len(inputs)}"
        )


def _main():
    parser = argparse.ArgumentParser(description="Validate delivery_pipeline config")
    parser.add_argument("--config", required=True)
    args = parser.parse_args()
    try:
        cfg = load_config(args.config)
    except ConfigError as e:
        print(f"INVALID: {e}", file=sys.stderr)
        sys.exit(1)
    print(
        f"OK: group_uuid={cfg['group_uuid']}, inputs={len(cfg['inputs'])}, "
        f"steps={cfg['steps']}"
    )


if __name__ == "__main__":
    _main()
