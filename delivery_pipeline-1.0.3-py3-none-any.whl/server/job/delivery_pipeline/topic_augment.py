"""Backfill missing topics from an upstream mcap into an algo's output mcap.

The vio algo (and potentially pose6d in the future) emits its own derived
topics plus a subset of pass-through topics from its input — for example the
ego-only vio image drops every /robot1/* and /robot2/* topic, including the
finger IMUs that the final delivery still needs.

This module reads the upstream mcap, filters it down to topics the algo's
output does NOT have, writes that filtered slice to a temp mcap, and then
hands the (primary, filtered_upstream) pair to merge_mcap.merge_mcap_files
— which is non-overlap-safe by construction.
"""
from __future__ import annotations

import logging
import os
import shutil
import tempfile
from typing import Optional, Tuple

from mcap.reader import NonSeekingReader
from mcap.writer import Writer

from server.job.framework.modules.merge_mcap import merge_mcap_files

logger = logging.getLogger("delivery_pipeline.topic_augment")


def _topic_set(mcap_path: str) -> set:
    topics: set = set()
    with open(mcap_path, "rb") as f:
        for _schema, channel, _msg in NonSeekingReader(f).iter_messages():
            topics.add(channel.topic)
    return topics


def _filter_to_topics(src_mcap: str, keep_topics: set, dst_mcap: str) -> int:
    schema_ids: dict = {}
    channel_ids: dict = {}
    written = 0
    with open(src_mcap, "rb") as f, open(dst_mcap, "wb") as out_f:
        reader = NonSeekingReader(f)
        writer = Writer(out_f)
        writer.start()
        for schema, channel, message in reader.iter_messages():
            if channel.topic not in keep_topics:
                continue
            schema_key = None
            if schema is not None:
                schema_key = (schema.name, schema.encoding, schema.data)
                if schema_key not in schema_ids:
                    schema_ids[schema_key] = writer.register_schema(
                        name=schema.name,
                        encoding=schema.encoding,
                        data=schema.data,
                    )
            channel_key = (channel.topic, channel.message_encoding, schema_key)
            if channel_key not in channel_ids:
                channel_ids[channel_key] = writer.register_channel(
                    schema_id=schema_ids[schema_key] if schema_key else 0,
                    topic=channel.topic,
                    message_encoding=channel.message_encoding,
                    metadata=channel.metadata,
                )
            writer.add_message(
                channel_id=channel_ids[channel_key],
                log_time=message.log_time,
                data=message.data,
                publish_time=message.publish_time,
            )
            written += 1
        writer.finish()
    return written


def augment_with_missing_topics(
    primary: str, secondary: str, output: str
) -> Tuple[bool, str, Optional[dict]]:
    """Write `output` = primary's messages ∪ secondary's messages on topics
    that primary does not contain.

    Returns `(ok, err_msg, data)`. On success `data["added_topics"]` is the
    sorted list of topics pulled in from `secondary`.
    """
    if not os.path.isfile(primary):
        return False, f"primary not found: {primary}", None
    if not os.path.isfile(secondary):
        return False, f"secondary not found: {secondary}", None

    primary_topics = _topic_set(primary)
    secondary_topics = _topic_set(secondary)
    missing = secondary_topics - primary_topics

    out_dir = os.path.dirname(output) or "."
    os.makedirs(out_dir, exist_ok=True)

    if not missing:
        shutil.copy2(primary, output)
        return True, "", {"added_topics": [], "total_messages": 0}

    fd, tmp_secondary = tempfile.mkstemp(
        suffix=".mcap", prefix="augment_secondary_", dir=out_dir
    )
    os.close(fd)
    try:
        _filter_to_topics(secondary, missing, tmp_secondary)
        ok, err, data = merge_mcap_files([primary, tmp_secondary], output)
        if ok and data is not None:
            data["added_topics"] = sorted(missing)
        return ok, err, data
    finally:
        try:
            os.remove(tmp_secondary)
        except OSError:
            pass
