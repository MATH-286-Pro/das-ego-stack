"""Pipeline image entrypoint.

Two modes:
  --config <job.yaml>        : run one group described by the yaml
  --input-dir + --output-dir : scan an mcap directory, group by uuid, run each

Image names for each algo step come from env vars; only the steps actually
listed in `--steps` (or `DEFAULT_STEPS`) need to be set:
  ALGO_QC_IMAGE, ALGO_MERGE_IMAGE, ALGO_VIO_IMAGE, ALGO_VIO_CHECK_IMAGE,
  ALGO_POSE6D_IMAGE, ALGO_POSE6D_CHECK_IMAGE, ALGO_CONVERT_IMAGE.

The default step list is read from the `DEFAULT_STEPS` env var so the two
pipeline images (short vs long variant) can bake in their own defaults.

Convenience: `--variant {vio,pose6d,c}` fills both DEFAULT_STEPS and the
per-step `ALGO_*_IMAGE` env (when not already set) from
`<ECR_REGISTRY>:<step>-<IMAGE_VERSION>`. Lets host-pip users skip the
7-env preamble. Variant `c` runs the full 6DPose flow without the
convert step (GPU still required for pose6d).
"""
from __future__ import annotations

import argparse
import logging
import os
import re
import sys
from collections import defaultdict
from dataclasses import dataclass, field
from typing import List

from server.job.delivery_pipeline import config_loader
from server.job.delivery_pipeline.runner import (
    ALL_STEPS,
    StepImages,
    _STEP_TO_ENV,
    run_group,
)

logger = logging.getLogger("delivery_pipeline.main")

EXIT_OK = 0
EXIT_CONFIG = 1
EXIT_PARTIAL = 2
EXIT_FATAL = 3

DEFAULT_ECR_REGISTRY = "764042516397.dkr.ecr.us-east-1.amazonaws.com/delivery"
DEFAULT_IMAGE_VERSION = "v1.0.3"

_VARIANT_STEPS = {
    "vio": "qc,merge,vio,vio_check",
    "pose6d": "qc,merge,vio,vio_check,pose6d,pose6d_check,convert",
    "c": "qc,merge,vio,vio_check,pose6d,pose6d_check",
}


def setup_logging(log_path: str = "") -> None:
    root = logging.getLogger()
    root.setLevel(logging.INFO)
    for h in list(root.handlers):
        root.removeHandler(h)
    fmt = logging.Formatter(
        "%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    sh = logging.StreamHandler()
    sh.setFormatter(fmt)
    root.addHandler(sh)
    if log_path:
        fh = logging.FileHandler(log_path, encoding="utf-8")
        fh.setFormatter(fmt)
        root.addHandler(fh)


_GROUP_UUID_RE = re.compile(r"_([0-9a-f]{8})\.mcap$")
_PLATFORM_HYPHEN_RE = re.compile(r"^(DAS-(?:EGO|F))-", re.IGNORECASE)
_PLATFORM_EGO_UNDERSCORE_RE = re.compile(r"^DAS-(?:Ego|EGO)_", re.IGNORECASE)
_PLATFORM_FINGER_RE = re.compile(r"(?:^das[_-]finger|_finger_)", re.IGNORECASE)
_BIZ_ROLE_ALIASES = (
    ("sub_left", "sub_left"),
    ("sub_right", "sub_right"),
    ("center_leader", "master"),
    ("leader", "master"),
    ("master", "master"),
)


@dataclass
class _Item:
    path: str
    platform: str
    biz_role: str


@dataclass
class _Group:
    uuid: str
    items: List[_Item] = field(default_factory=list)


def _parse_filename(filename: str):
    if _PLATFORM_HYPHEN_RE.match(filename):
        platform = _PLATFORM_HYPHEN_RE.match(filename).group(1).upper()
    elif _PLATFORM_EGO_UNDERSCORE_RE.match(filename):
        platform = "DAS-EGO"
    elif _PLATFORM_FINGER_RE.search(filename):
        platform = "DAS-F"
    else:
        return None

    stem = filename.lower()
    biz_role = None
    for tok, canonical in _BIZ_ROLE_ALIASES:
        if f"_{tok}_" in stem or stem.endswith(f"_{tok}.mcap"):
            biz_role = canonical
            break
    if biz_role is None:
        return None
    return platform, biz_role


def discover_groups(input_dir: str) -> List[_Group]:
    files = sorted(f for f in os.listdir(input_dir) if f.endswith(".mcap"))

    parsed: list = []
    finger_uuids: set = set()
    ego_pending: list = []

    for name in files:
        info = _parse_filename(name)
        if info is None:
            logger.warning("skip (unparsed name): %s", name)
            continue
        platform, biz_role = info
        full = os.path.join(input_dir, name)
        m = _GROUP_UUID_RE.search(name)
        if m:
            uuid = m.group(1)
            parsed.append((uuid, _Item(full, platform, biz_role)))
            if platform == "DAS-F":
                finger_uuids.add(uuid)
        else:
            ego_pending.append((name, _Item(full, platform, biz_role)))

    for name, item in ego_pending:
        stem = name.lower()
        hits = [u for u in finger_uuids
                if re.search(rf"(?:^|_){u}(?:$|_|\.)", stem)]
        if len(hits) == 1:
            parsed.append((hits[0], item))
        else:
            logger.warning("skip (ego matches %d candidate uuids): %s", len(hits), name)

    by_uuid: dict = defaultdict(list)
    for uuid, item in parsed:
        by_uuid[uuid].append(item)
    return [_Group(uuid=u, items=its) for u, its in sorted(by_uuid.items())]


def _is_complete(g: _Group):
    roles = {(it.platform, it.biz_role) for it in g.items}
    want = {("DAS-EGO", "master"), ("DAS-F", "sub_left"), ("DAS-F", "sub_right")}
    miss = want - roles
    extra = roles - want
    if miss or extra:
        return False, f"missing={sorted(miss)} extra={sorted(extra)}"
    return True, ""


def _cfg_for_group(g: _Group, output_root: str, input_dir: str,
                   steps: list) -> dict:
    cfg = {
        "inputs": [{"file_path": it.path} for it in g.items],
        "output_dir": os.path.join(output_root, g.uuid),
        "input_dir": input_dir,
        "steps": list(steps),
    }
    os.makedirs(cfg["output_dir"], exist_ok=True)
    return config_loader.normalize(cfg)


def _run_single(cfg: dict, images: StepImages, input_dir: str, network: str):
    res = run_group(cfg, images, input_dir=input_dir, network=network)
    logger.info("group %s: overall=%s failed_at=%s",
                res.group_uuid, res.overall, res.failed_at)
    return res


def _default_steps() -> str:
    return os.environ.get("DEFAULT_STEPS", ",".join(ALL_STEPS))


def main(argv=None) -> int:
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--config", help="single-group job.yaml (alternative to --input-dir)")
    p.add_argument("--input-dir", help="batch mode: directory of mcaps to group and process")
    p.add_argument("--output-dir", help="batch mode: per-group result root")
    p.add_argument("--variant", choices=sorted(_VARIANT_STEPS),
                   help="fill DEFAULT_STEPS + per-step ALGO_*_IMAGE env from "
                        "<ecr-registry>:<step>-<image-version> for the chosen "
                        "variant ('vio' = short flow, 'pose6d' = long flow, "
                        "'c' = full 6DPose flow without convert). "
                        "Explicit --steps and ALGO_*_IMAGE env take precedence.")
    p.add_argument("--ecr-registry",
                   default=os.environ.get("ECR_REGISTRY", DEFAULT_ECR_REGISTRY),
                   help=f"image registry base used by --variant (default: {DEFAULT_ECR_REGISTRY})")
    p.add_argument("--image-version",
                   default=os.environ.get("IMAGE_VERSION", DEFAULT_IMAGE_VERSION),
                   help=f"image tag suffix used by --variant (default: {DEFAULT_IMAGE_VERSION})")
    p.add_argument("--steps", default=None,
                   help="comma-separated subset of steps to run "
                        "(default from --variant, else DEFAULT_STEPS env var)")
    p.add_argument("--network", default=os.environ.get("ALGO_NETWORK", "none"),
                   help="docker --network value for spawned algo containers (default: none)")
    p.add_argument("--continue-on-error", action="store_true",
                   help="when one group fails, keep going to the next (default: stop)")
    args = p.parse_args(argv)

    if args.variant:
        steps_default = _VARIANT_STEPS[args.variant]
        for step in steps_default.split(","):
            env_name = _STEP_TO_ENV[step]
            if not os.environ.get(env_name):
                os.environ[env_name] = f"{args.ecr_registry}:{step}-{args.image_version}"
    else:
        steps_default = _default_steps()

    args.steps = args.steps or steps_default

    out_root = args.output_dir or (os.path.dirname(args.config) if args.config else None)
    if out_root:
        os.makedirs(out_root, exist_ok=True)
        setup_logging(os.path.join(out_root, "pipeline.log"))
    else:
        setup_logging("")

    steps = [s.strip() for s in args.steps.split(",") if s.strip()]
    bad = [s for s in steps if s not in ALL_STEPS]
    if bad:
        logger.error("invalid --steps entries: %s", bad)
        return EXIT_CONFIG

    try:
        images = StepImages.from_env(steps)
    except KeyError as e:
        logger.error("missing required env var(s) for selected steps: %s", e)
        logger.error("set the ALGO_*_IMAGE env var for each step in --steps")
        return EXIT_CONFIG

    if args.config:
        try:
            cfg = config_loader.load_config(args.config)
        except config_loader.ConfigError as e:
            logger.error("config error: %s", e)
            return EXIT_CONFIG
        cfg["steps"] = steps
        input_dir = cfg.get("input_dir") or os.path.dirname(
            cfg["inputs"][0]["file_path"]
        )
        res = _run_single(cfg, images, input_dir, args.network)
        return EXIT_OK if res.overall == "success" else EXIT_PARTIAL

    if not (args.input_dir and args.output_dir):
        logger.error("either --config or (--input-dir AND --output-dir) is required")
        return EXIT_CONFIG

    input_dir = os.path.realpath(args.input_dir)
    output_root = os.path.realpath(args.output_dir)
    groups = discover_groups(input_dir)
    logger.info("discovered %d candidate group(s) in %s", len(groups), input_dir)

    plan = []
    for g in groups:
        ok, why = _is_complete(g)
        marker = "OK" if ok else "SKIP"
        roles = ", ".join(f"{it.platform}/{it.biz_role}"
                          for it in sorted(g.items, key=lambda x: (x.platform, x.biz_role)))
        logger.info("  [%s] %s: %d files [%s]%s",
                    marker, g.uuid, len(g.items), roles, f" — {why}" if not ok else "")
        if ok:
            plan.append(g)

    if not plan:
        logger.error("no complete groups, nothing to run")
        return EXIT_CONFIG

    failures = []
    for g in plan:
        try:
            cfg = _cfg_for_group(g, output_root, input_dir, steps)
        except config_loader.ConfigError as e:
            logger.error("group %s config error: %s", g.uuid, e)
            failures.append((g.uuid, "config_error"))
            if not args.continue_on_error:
                break
            continue
        res = _run_single(cfg, images, input_dir, args.network)
        if res.overall != "success":
            failures.append((g.uuid, res.failed_at or "unknown"))
            if not args.continue_on_error:
                logger.error("group %s failed at %s; stopping (pass --continue-on-error to keep going)",
                             g.uuid, res.failed_at)
                break

    logger.info("summary: %d/%d groups succeeded", len(plan) - len(failures), len(plan))
    for uuid, where in failures:
        logger.error("  FAIL %s at %s", uuid, where)
    return EXIT_OK if not failures else EXIT_PARTIAL


if __name__ == "__main__":
    sys.exit(main())
