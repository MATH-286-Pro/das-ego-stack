import os
import json
import logging
import contextvars
from aenum import StrEnum
from datetime import datetime
from dataclasses import dataclass
from typing import Optional, Dict, Any

# ------------------- 环境配置 -------------------
_ENV = os.getenv("ENV", "local")
_MODULE_NAME = os.getenv("MODULE_NAME", "")
_NODE_NAME = os.getenv("NODE_NAME", "")
IS_IN_K8S = "KUBERNETES_SERVICE_HOST" in os.environ
IS_IN_K8S = True

# ------------------- 日志模版 -------------------
@dataclass
class LogFields:
    batch_id: Optional[str] = None
    group: Optional[str] = None
    token: Optional[str] = None
    cpu_seqs: Optional[str] = None
    category: Optional[str] = None
    sub_category: Optional[str] = None
    extra: Optional[Dict[str, Any]] = None  # 业务扩展字段

# ====================== JSON 格式化 Handler ======================
class JsonConsoleHandler(logging.StreamHandler):
    def __init__(self):
        super().__init__()
        self.env = _ENV
        self.module = _MODULE_NAME
        self.node = _NODE_NAME

    def format(self, record):
        # 取出你的 LogFields
        fields: LogFields = getattr(record, "fields", LogFields())

        log_obj = {
            "env": self.env,
            "module": self.module,
            "node": self.node,
            "batch_id": fields.batch_id or get_global_batch_id(),
            "group": fields.group or get_global_group(),
            "token": fields.token or get_global_token(),
            "event_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3],
            "log_level": record.levelname,
            "category": fields.category or "",
            "sub_category": fields.sub_category or "",
            "message": record.getMessage(),
            "cpu_seqs": fields.cpu_seqs or get_global_cpu_seqs(),
            "extra": fields.extra or {}
        }

        # 过滤掉值为空的键
        filtered_log_obj = {
            k: v for k, v in log_obj.items() if v
        }

        return json.dumps(filtered_log_obj, ensure_ascii=False)

# ====================== 日志实现类 ======================
class AppLogger:
    def __init__(self, logger_name: str = "app"):
        self.logger = logging.getLogger(logger_name)
        self.logger.setLevel(logging.DEBUG)
        self.logger.handlers.clear()  # 避免重复

        if IS_IN_K8S:
            # 日志输出为json格式
            console_handler = JsonConsoleHandler()
        else:
            # 日志输出为字符串格式
            console_handler = logging.StreamHandler()
            console_handler.setFormatter(
                logging.Formatter("%(asctime)s %(levelname)s %(message)s")
            )

        self.logger.addHandler(console_handler)

    def debug(self, msg: str, fields: LogFields = None):
        self.logger.debug(msg, extra={"fields": fields or LogFields()})

    def info(self, msg: str, fields: LogFields = None):
        self.logger.info(msg, extra={"fields": fields or LogFields()})

    def warn(self, msg: str, fields: LogFields = None):
        self.logger.warning(msg, extra={"fields": fields or LogFields()})

    def error(self, msg: str, fields: LogFields = None):
        self.logger.error(msg, extra={"fields": fields or LogFields()})

    def info_or_error(self, success: bool, msg: str, fields: LogFields = None):
        if success:
            self.info(msg, fields)
        else:
            self.error(msg, fields)

# 全局单例（和你原来完全一样）
logger = AppLogger()

# ContextVar 用于按线程/异步上下文隔离日志上下文（流水线并发改造，多个线程同时跑不同任务时不互相覆盖）
_token_var: contextvars.ContextVar[Optional[str]] = contextvars.ContextVar("global_token", default=None)
_group_var: contextvars.ContextVar[Optional[str]] = contextvars.ContextVar("global_group", default=None)
_cpu_seqs_var: contextvars.ContextVar[Optional[str]] = contextvars.ContextVar("global_cpu_seqs", default=None)
_batch_id_var: contextvars.ContextVar[Optional[str]] = contextvars.ContextVar("global_batch_id", default=None)

def set_global_token(token: str):
    _token_var.set(token)

def get_global_token():
    return _token_var.get()

def set_global_group(group: str):
    _group_var.set(group)

def get_global_group():
    return _group_var.get()

def set_global_cpu_seqs(cpu_seqs: str):
    _cpu_seqs_var.set(cpu_seqs)

def get_global_cpu_seqs():
    return _cpu_seqs_var.get()

def set_global_batch_id(batch_id: str):
    _batch_id_var.set(batch_id)

def get_global_batch_id():
    return _batch_id_var.get()

class CustomLogCategory(StrEnum):
    PROGRAM_EXCEPTION = "通用错误-程序异常"
    API_INTERFACE_FAILED = "通用错误-API接口调用失败"
    PARAM_DATA_ERROR = "通用错误-参数或数据异常"

class CustomLogSubCategory(StrEnum):
    NETWORK_EXCEPTION = "网络异常" 
    API_REQUEST_FAILED = "API请求失败"
    API_RESPONSE_FAILED = "API响应失败"
    FILE_DOWNLOAD_FAILED = "文件下载失败"
    FILE_UPLOAD_FAILED = "文件上传失败"