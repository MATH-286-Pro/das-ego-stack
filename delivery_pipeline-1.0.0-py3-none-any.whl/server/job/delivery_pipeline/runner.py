"""Step orchestration for the delivery pipeline.

Runs each step in its own container via `docker run`. The pipeline image
mounts the host docker socket and identity-binds the host workdir so the
host paths it embeds in each step's JSON context resolve to the same files
both inside the pipeline image and inside the spawned algo image.

Two algo-side quirks dictate the workdir layout:
- vio_egox writes to a hardcoded `/app/data/output`, so the vio container
  gets `work/vio/` bound to that path.
- integrity_check `rmtree`s its output_dir when done, so vio_check is given
  a scratch `work/vio_check/` dir distinct from where vio's products live.

Supports two delivery variants by virtue of the `steps` list:
- short:  qc, merge, vio, vio_check, convert
- long:   qc, merge, vio, vio_check, pose6d, pose6d_check, convert
"""
from __future__ import annotations

import glob
import logging
import os
import shlex
import shutil
import subprocess
import time
from dataclasses import dataclass, field
from typing import Optional

from server.job.delivery_pipeline.output_cleanup import trim_output_dir
from server.job.delivery_pipeline.step_io import read_json, write_json
from server.job.delivery_pipeline.topic_augment import augment_with_missing_topics

logger = logging.getLogger("delivery_pipeline.runner")

STEP_QC = "qc"
STEP_MERGE = "merge"
STEP_VIO = "vio"
STEP_VIO_CHECK = "vio_check"
STEP_POSE6D = "pose6d"
STEP_POSE6D_CHECK = "pose6d_check"
STEP_CONVERT = "convert"

ALL_STEPS = (
    STEP_QC, STEP_MERGE, STEP_VIO, STEP_VIO_CHECK,
    STEP_POSE6D, STEP_POSE6D_CHECK, STEP_CONVERT,
)

# vio_egox writes to this hardcoded path; we bind work/vio/ over it.
VIO_ALGO_OUTPUT_DIR = "/app/data/output"

# Steps that need GPU access. The pose6d inference model calls `model.to(cuda)`
# and will crash on CPU-only hosts. Each entry is the default `--gpus` value
# (passed verbatim to docker run); override per step via env
# `ALGO_<STEP>_GPUS` (e.g. `ALGO_POSE6D_GPUS=device=0`, or empty to disable).
_STEP_GPU_DEFAULTS = {
    STEP_POSE6D: "all",
}


def _gpu_spec_for(step: str) -> str:
    """Return the `--gpus` value for `step`, or empty string if no GPU needed."""
    env_key = f"ALGO_{step.upper()}_GPUS"
    if env_key in os.environ:
        return os.environ[env_key].strip()
    return _STEP_GPU_DEFAULTS.get(step, "")

_STEP_TO_ENV = {
    STEP_QC: "ALGO_QC_IMAGE",
    STEP_MERGE: "ALGO_MERGE_IMAGE",
    STEP_VIO: "ALGO_VIO_IMAGE",
    STEP_VIO_CHECK: "ALGO_VIO_CHECK_IMAGE",
    STEP_POSE6D: "ALGO_POSE6D_IMAGE",
    STEP_POSE6D_CHECK: "ALGO_POSE6D_CHECK_IMAGE",
    STEP_CONVERT: "ALGO_CONVERT_IMAGE",
}


@dataclass
class StepImages:
    """Per-step docker image names, populated lazily from env.

    Only the steps actually requested need to be present in the environment;
    accessing a missing one raises a clear KeyError.
    """
    qc: Optional[str] = None
    merge: Optional[str] = None
    vio: Optional[str] = None
    vio_check: Optional[str] = None
    pose6d: Optional[str] = None
    pose6d_check: Optional[str] = None
    convert: Optional[str] = None

    @classmethod
    def from_env(cls, steps=None) -> "StepImages":
        """Read ALGO_*_IMAGE from env for the given steps.

        If `steps` is None, read all known step images that happen to be set
        (no error for missing ones). If `steps` is a list, every requested
        step's env var MUST be set, else KeyError.
        """
        out = cls()
        if steps is None:
            for step, env in _STEP_TO_ENV.items():
                val = os.environ.get(env)
                if val:
                    setattr(out, step, val)
            return out
        missing = []
        for step in steps:
            env = _STEP_TO_ENV.get(step)
            if env is None:
                continue
            val = os.environ.get(env)
            if not val:
                missing.append(env)
            else:
                setattr(out, step, val)
        if missing:
            raise KeyError(", ".join(missing))
        return out

    def for_step(self, step: str) -> str:
        val = getattr(self, step, None)
        if not val:
            raise KeyError(_STEP_TO_ENV[step])
        return val


@dataclass
class GroupResult:
    group_uuid: str
    overall: str = "success"  # "success" | "failed"
    failed_at: Optional[str] = None
    steps: list = field(default_factory=list)


def run_group(cfg: dict, images: StepImages, *, input_dir: str,
              network: str = "none", continue_on_step_error: bool = False) -> GroupResult:
    """Run all configured steps for one group.

    `cfg` is the dict produced by config_loader.load_config (or its in-memory
    equivalent built by main.scan_groups). `input_dir` is the host directory
    holding the raw mcaps; identity-bind-mounted into algo containers that
    need to read them (qc, merge).
    """
    group_uuid = cfg["group_uuid"]
    output_root = cfg["output_dir"]
    steps = cfg.get("steps") or list(ALL_STEPS)

    work = os.path.join(output_root, "work")
    paths = {
        "work": work,
        "step_inputs": os.path.join(work, "step_inputs"),
        "step_outputs": os.path.join(work, "step_outputs"),
        "temp": os.path.join(work, "temp"),
        "merge_out": os.path.join(work, "merge"),
        "vio_out": os.path.join(work, "vio"),
        "vio_check_out": os.path.join(work, "vio_check"),
        "pose6d_out": os.path.join(work, "pose6d"),
        "pose6d_check_out": os.path.join(work, "pose6d_check"),
        "convert_out": os.path.join(work, "convert"),
    }
    for p in paths.values():
        os.makedirs(p, exist_ok=True)

    base_ctx = _base_context(cfg, paths)
    summary = GroupResult(group_uuid=group_uuid)
    merged_mcap = None
    vio_output_mcap = None
    pose6d_output_mcap = None
    last_mcap = None  # most recent valid mcap for downstream steps

    if STEP_QC in steps:
        ctx = dict(base_ctx, job_name="qc", output_dir=output_root)
        result = _run_step(STEP_QC, ctx, images.for_step(STEP_QC), paths,
                           extra_mounts=[(input_dir, input_dir, "ro")],
                           network=network)
        summary.steps.append(result)
        if result["status"] != "success":
            summary.overall = "failed"
            summary.failed_at = STEP_QC
            if not continue_on_step_error:
                return _finalize(output_root, summary, success=False)

    if STEP_MERGE in steps and (summary.overall == "success" or continue_on_step_error):
        ctx = dict(base_ctx, job_name="merge", output_dir=paths["merge_out"])
        result = _run_step(STEP_MERGE, ctx, images.for_step(STEP_MERGE), paths,
                           extra_mounts=[(input_dir, input_dir, "ro")],
                           network=network)
        summary.steps.append(result)
        if result["status"] != "success":
            summary.overall = "failed"
            summary.failed_at = STEP_MERGE
            if not continue_on_step_error:
                return _finalize(output_root, summary, success=False)
        else:
            merged_mcap = result.get("output_path") or os.path.join(
                paths["merge_out"], "merged_output.mcap"
            )
            last_mcap = merged_mcap

    if STEP_VIO in steps and (summary.overall == "success" or continue_on_step_error):
        if not merged_mcap:
            merged_mcap = _find_step_mcap(paths, output_root, "merge_out")
        if not merged_mcap:
            summary.overall = "failed"
            summary.failed_at = STEP_VIO
            summary.steps.append({
                "step": STEP_VIO,
                "status": "failed",
                "error_msg": "no merge output mcap available for vio",
            })
            if not continue_on_step_error:
                return _finalize(output_root, summary, success=False)
            # fall through to subsequent steps' resume-fallbacks
        else:
            ctx = dict(
                base_ctx,
                job_name="vio",
                output_dir=paths["vio_out"],
                input_infos=[{"db_info": {"key": "process_merge_origin"},
                              "file_path": merged_mcap}],
            )
            # bind work/vio/ over the algo's hardcoded /app/data/output
            result = _run_step(
                STEP_VIO, ctx, images.for_step(STEP_VIO), paths,
                extra_mounts=[(paths["vio_out"], VIO_ALGO_OUTPUT_DIR, "rw")],
                network=network,
            )
            summary.steps.append(result)
            if result["status"] != "success":
                summary.overall = "failed"
                summary.failed_at = STEP_VIO
                if not continue_on_step_error:
                    return _finalize(output_root, summary, success=False)
            else:
                # algo's output_path is the in-container `/app/data/output/foo.mcap`;
                # translate to the host-side bind target so the pipeline can find it.
                vio_output_mcap = _find_mcap_in(paths["vio_out"])
                if not vio_output_mcap:
                    summary.overall = "failed"
                    summary.failed_at = STEP_VIO
                    result["status"] = "failed"
                    result["error_msg"] = result.get("error_msg") or "no mcap found in vio output dir"
                    if not continue_on_step_error:
                        return _finalize(output_root, summary, success=False)
                else:
                    # Backfill topics that vio dropped (finger IMU, finger
                    # cameras, magnetic_encoder, …). Downstream — pose6d_check
                    # and convert — both expect those topics.
                    if merged_mcap and os.path.isfile(merged_mcap):
                        vio_output_mcap = _augment_or_keep(
                            STEP_VIO, vio_output_mcap, merged_mcap, paths["vio_out"],
                        )
                    last_mcap = vio_output_mcap

    if STEP_VIO_CHECK in steps and (summary.overall == "success" or continue_on_step_error):
        if not vio_output_mcap:
            vio_output_mcap = _find_step_mcap(paths, output_root, "vio_out")
        if not vio_output_mcap:
            summary.overall = "failed"
            summary.failed_at = STEP_VIO_CHECK
            summary.steps.append({
                "step": STEP_VIO_CHECK,
                "status": "failed",
                "error_msg": "no vio output mcap available for integrity check",
            })
            if not continue_on_step_error:
                return _finalize(output_root, summary, success=False)
        else:
            ctx = dict(
                base_ctx,
                job_name="vio_check",
                output_dir=paths["vio_check_out"],
                input_infos=[{"db_info": {"key": "process_vio_origin"},
                              "file_path": vio_output_mcap}],
                input_merged_path=vio_output_mcap,
            )
            result = _run_step(STEP_VIO_CHECK, ctx, images.for_step(STEP_VIO_CHECK), paths,
                               extra_mounts=[], network=network)
            summary.steps.append(result)
            if result["status"] != "success":
                summary.overall = "failed"
                summary.failed_at = STEP_VIO_CHECK
                if not continue_on_step_error:
                    return _finalize(output_root, summary, success=False)

    if STEP_POSE6D in steps and (summary.overall == "success" or continue_on_step_error):
        # pose6d works on a directory of mcaps (its bash script globs *.mcap);
        # the vio output dir holds the canonical mcap PLUS an `_interpolated`
        # sibling, so we have to stage only the canonical one into a clean
        # dir before pointing pose6d at it. If vio didn't run this invocation
        # (resume-mid-pipeline), fall back to whatever a prior run left under
        # work/ or debug/work/.
        if not vio_output_mcap:
            vio_output_mcap = _find_step_mcap(paths, output_root, "vio_out")
        pose6d_input_mcap = vio_output_mcap or last_mcap
        if not pose6d_input_mcap:
            summary.overall = "failed"
            summary.failed_at = STEP_POSE6D
            summary.steps.append({
                "step": STEP_POSE6D,
                "status": "failed",
                "error_msg": "no upstream mcap available for pose6d",
            })
            if not continue_on_step_error:
                return _finalize(output_root, summary, success=False)
        else:
            staged_dir = os.path.join(paths["pose6d_out"], "_input")
            staged_mcap = _stage_single_mcap(pose6d_input_mcap, staged_dir)
            ctx = dict(
                base_ctx,
                job_name="pose6d",
                output_dir=paths["pose6d_out"],
                input_infos=[{"db_info": {"key": "process_vio_origin"},
                              "file_path": staged_mcap}],
                input_merged_path=staged_mcap,
            )
            result = _run_step(STEP_POSE6D, ctx, images.for_step(STEP_POSE6D), paths,
                               extra_mounts=[], network=network)
            summary.steps.append(result)
            if result["status"] != "success":
                summary.overall = "failed"
                summary.failed_at = STEP_POSE6D
                if not continue_on_step_error:
                    return _finalize(output_root, summary, success=False)
            else:
                pose6d_output_mcap = result.get("output_path") or _find_mcap_in(paths["pose6d_out"])
                if pose6d_output_mcap:
                    # Same idea as after vio: if pose6d dropped any topic
                    # the upstream (augmented vio output) carried, backfill
                    # so convert and any future check sees the full topic set.
                    if pose6d_input_mcap and os.path.isfile(pose6d_input_mcap):
                        pose6d_output_mcap = _augment_or_keep(
                            STEP_POSE6D, pose6d_output_mcap, pose6d_input_mcap,
                            paths["pose6d_out"],
                        )
                    last_mcap = pose6d_output_mcap

    if STEP_POSE6D_CHECK in steps and (summary.overall == "success" or continue_on_step_error):
        if not pose6d_output_mcap:
            pose6d_output_mcap = _find_step_mcap(paths, output_root, "pose6d_out")
        if not pose6d_output_mcap:
            summary.overall = "failed"
            summary.failed_at = STEP_POSE6D_CHECK
            summary.steps.append({
                "step": STEP_POSE6D_CHECK,
                "status": "failed",
                "error_msg": "no pose6d output mcap available for pose6d_check",
            })
            if not continue_on_step_error:
                return _finalize(output_root, summary, success=False)
        else:
            ctx = dict(
                base_ctx,
                job_name="pose6d_check",
                output_dir=paths["pose6d_check_out"],
                input_infos=[{"db_info": {"key": "process_finger_6d_pose"},
                              "file_path": pose6d_output_mcap}],
                input_merged_path=pose6d_output_mcap,
            )
            result = _run_step(STEP_POSE6D_CHECK, ctx, images.for_step(STEP_POSE6D_CHECK),
                               paths, extra_mounts=[], network=network)
            summary.steps.append(result)
            if result["status"] != "success":
                summary.overall = "failed"
                summary.failed_at = STEP_POSE6D_CHECK
                if not continue_on_step_error:
                    return _finalize(output_root, summary, success=False)

    if STEP_CONVERT in steps and (summary.overall == "success" or continue_on_step_error):
        # Resume-fallback: if upstream steps didn't run this invocation,
        # try to recover their outputs from a prior run (work/ or debug/work/).
        if not pose6d_output_mcap:
            pose6d_output_mcap = _find_step_mcap(paths, output_root, "pose6d_out")
        if not vio_output_mcap:
            vio_output_mcap = _find_step_mcap(paths, output_root, "vio_out")
        convert_input_mcap = pose6d_output_mcap or vio_output_mcap or last_mcap
        if not convert_input_mcap:
            summary.overall = "failed"
            summary.failed_at = STEP_CONVERT
            summary.steps.append({
                "step": STEP_CONVERT,
                "status": "failed",
                "error_msg": "no upstream mcap available for convert",
            })
            if not continue_on_step_error:
                return _finalize(output_root, summary, success=False)
        else:
            ctx = dict(
                base_ctx,
                job_name="convert",
                output_dir=paths["convert_out"],
                input_infos=[{"db_info": {"key": "process_delivery_input"},
                              "file_path": convert_input_mcap}],
                input_merged_path=convert_input_mcap,
            )
            result = _run_step(STEP_CONVERT, ctx, images.for_step(STEP_CONVERT), paths,
                               extra_mounts=[], network=network)
            summary.steps.append(result)
            if result["status"] != "success":
                summary.overall = "failed"
                summary.failed_at = STEP_CONVERT
                if not continue_on_step_error:
                    return _finalize(output_root, summary, success=False)

    success = (summary.overall == "success")

    if success:
        _publish_final_artefacts(output_root, paths, steps,
                                 vio_output_mcap, pose6d_output_mcap)

    return _finalize(output_root, summary, success=success)


def _publish_final_artefacts(output_root: str, paths: dict, steps: list,
                             vio_output_mcap: Optional[str],
                             pose6d_output_mcap: Optional[str]) -> None:
    """Copy the final per-group artefacts into the group root.

    If convert ran, publish only its `delivery.mcap`. The matching
    `metadata.json` is intentionally kept inside the convert work dir
    (which `output_cleanup` parks under `debug/work/convert/`) — it's
    available for forensics but not part of the user-facing root layout.
    If convert did NOT run, fall back to the legacy
    `merged_output_ego_vio.mcap` from vio so short-variant runs without
    convert still surface a final mcap.
    """
    convert_mcap = os.path.join(paths["convert_out"], "delivery.mcap")
    if STEP_CONVERT in steps and os.path.isfile(convert_mcap):
        _safe_copy(convert_mcap, os.path.join(output_root, "delivery.mcap"))
        return

    final_src = vio_output_mcap or pose6d_output_mcap
    if final_src and os.path.isfile(final_src):
        _safe_copy(final_src, os.path.join(output_root, "merged_output_ego_vio.mcap"))


def _safe_copy(src: str, dst: str) -> None:
    try:
        shutil.copy2(src, dst)
    except OSError as e:
        logger.error("could not copy %s -> %s: %s", src, dst, e)


def _base_context(cfg: dict, paths: dict) -> dict:
    return {
        "pipeline_name": "delivery_pipeline",
        "job_name": "",
        "group_uuid": cfg["group_uuid"],
        "task_params": cfg.get("task_params") or {},
        "program_version": cfg.get("program_version") or "compose",
        "group_info": cfg.get("group_info") or {},
        "input_dir": cfg.get("input_dir") or "",
        "output_dir": cfg["output_dir"],
        "temp_dir": paths["temp"],
        "input_infos": [
            {
                "db_info": {
                    k: item.get(k) for k in (
                        "token", "platform", "biz_role", "cpu_seq",
                        "duration", "record_time_ms", "group_count",
                    )
                },
                "file_path": item["file_path"],
            }
            for item in cfg["inputs"]
        ],
    }


def _run_step(step: str, ctx: dict, image: str, paths: dict,
              *, extra_mounts: list, network: str) -> dict:
    in_path = os.path.join(paths["step_inputs"], f"{step}.json")
    out_path = os.path.join(paths["step_outputs"], f"{step}.json")
    write_json(in_path, {"step": step, "context": ctx})

    cmd = ["docker", "run", "--rm", f"--network={network}",
           "--user", f"{os.getuid()}:{os.getgid()}",
           "-e", "HOME=/tmp"]
    gpu_spec = _gpu_spec_for(step)
    if gpu_spec:
        cmd += [f"--gpus={gpu_spec}"]
    mounts = [(paths["work"], paths["work"], "rw")] + extra_mounts
    for src, dst, mode in mounts:
        cmd += ["-v", f"{src}:{dst}:{mode}"]
    cmd += [image, "--in", in_path, "--out", out_path]

    logger.info("=== step=%s image=%s ===", step, image)
    logger.info("%s", " ".join(shlex.quote(c) for c in cmd))
    started = time.time()
    rc = _stream(cmd, f"[{step}]")
    elapsed = round(time.time() - started, 3)

    if os.path.isfile(out_path):
        result = read_json(out_path)
    else:
        result = {"step": step, "status": "failed",
                  "error_msg": f"step {step} produced no output file (rc={rc})"}
    result["elapsed_sec"] = elapsed
    result["container_exit"] = rc
    if rc != 0 and result.get("status") == "success":
        # container died but somehow wrote success; trust the exit code.
        result["status"] = "failed"
        result["error_msg"] = (result.get("error_msg") or "") + \
            f" (container rc={rc} but JSON said success)"
    return result


def _stream(cmd: list, prefix: str) -> int:
    proc = subprocess.Popen(
        cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        bufsize=1, text=True,
    )
    assert proc.stdout is not None
    for line in proc.stdout:
        logger.info("%s %s", prefix, line.rstrip())
    return proc.wait()


def _find_mcap_in(directory: str) -> Optional[str]:
    cands = sorted(glob.glob(os.path.join(directory, "*.mcap")))
    return cands[0] if cands else None


def _stage_single_mcap(src_mcap: str, staged_dir: str) -> str:
    """Symlink (or hardlink/copy) a single mcap into a fresh, otherwise empty
    directory, and return the new path. pose6d's `run_6dpose_infer.sh` globs
    `*.mcap` from its `--input-dir`, so handing it the vio output dir (which
    holds both `merged_output_ego_vio.mcap` and a `_interpolated` sibling)
    would feed it two inputs. Staging gives it exactly one.
    """
    os.makedirs(staged_dir, exist_ok=True)
    for f in glob.glob(os.path.join(staged_dir, "*.mcap")):
        try:
            os.remove(f)
        except OSError:
            pass
    dst = os.path.join(staged_dir, os.path.basename(src_mcap))
    try:
        os.symlink(src_mcap, dst)
    except OSError:
        # cross-filesystem or no-symlink filesystems
        try:
            os.link(src_mcap, dst)
        except OSError:
            shutil.copy2(src_mcap, dst)
    return dst


def _augment_or_keep(step: str, algo_mcap: str, upstream_mcap: str,
                     workdir: str) -> str:
    """Backfill missing topics from `upstream_mcap` into `algo_mcap`.

    Writes to a sibling `<base>_full.mcap`, replaces `algo_mcap` with it on
    success (the original is moved to `<base>.algo_only.mcap` for debugging),
    and returns the path that downstream steps should use. Any failure logs
    and returns `algo_mcap` unchanged so we never make things worse.
    """
    base = os.path.splitext(os.path.basename(algo_mcap))[0]
    out_path = os.path.join(workdir, f"{base}_full.mcap")
    try:
        ok, err, data = augment_with_missing_topics(algo_mcap, upstream_mcap, out_path)
    except Exception as e:
        logger.warning("[%s] topic augmentation crashed: %s; keeping algo-only output",
                       step, e)
        return algo_mcap
    if not ok:
        logger.warning("[%s] topic augmentation failed: %s; keeping algo-only output",
                       step, err)
        return algo_mcap
    added = (data or {}).get("added_topics", [])
    if not added:
        # upstream had no extra topics; drop the redundant copy and keep the
        # original path.
        try:
            os.remove(out_path)
        except OSError:
            pass
        return algo_mcap
    logger.info("[%s] backfilled %d topic(s) from upstream: %s",
                step, len(added), added)
    # Keep the original at <base>.algo_only.mcap.bak so subsequent
    # `_find_mcap_in` glob calls (which match *.mcap) don't pick it up.
    backup = os.path.join(workdir, f"{base}.algo_only.mcap.bak")
    try:
        os.replace(algo_mcap, backup)
        os.replace(out_path, algo_mcap)
    except OSError as e:
        logger.warning("[%s] could not swap augmented mcap into place: %s; "
                       "downstream will read %s directly", step, e, out_path)
        return out_path
    return algo_mcap


def _find_step_mcap(paths: dict, output_root: str, step_key: str) -> Optional[str]:
    """Locate a step's output mcap, surviving across runs.

    Looks in three places, in order:
      1. work/<step>/         — this run, or a previous run that failed
                                before _finalize moved things into debug/.
      2. debug/work/<step>/   — a previous successful run; output_cleanup
                                relocates work/ here on success.
      3. <output_root>/merged_output_ego_vio.mcap — vio's legacy
                                short-variant published artefact, only used
                                when step_key == "vio_out".
    Returns the first match, or None.
    """
    primary = paths.get(step_key)
    if primary:
        hit = _find_mcap_in(primary)
        if hit:
            return hit
    # work/ was moved into debug/ by output_cleanup.trim_output_dir on
    # a previous successful run. Mirror the subpath under debug/work/.
    if primary:
        rel = os.path.relpath(primary, output_root)
        debug_path = os.path.join(output_root, "debug", rel)
        hit = _find_mcap_in(debug_path)
        if hit:
            return hit
    if step_key == "vio_out":
        legacy = os.path.join(output_root, "merged_output_ego_vio.mcap")
        if os.path.isfile(legacy):
            return legacy
    return None


def _finalize(output_root: str, summary: GroupResult, *, success: bool) -> GroupResult:
    final = {
        "group_uuid": summary.group_uuid,
        "code": "success" if success else "fail",
        "overall": summary.overall,
        "failed_at": summary.failed_at,
        "steps": summary.steps,
    }
    write_json(os.path.join(output_root, "result.json"), final)
    if success:
        trim_output_dir(output_root)
    return summary
